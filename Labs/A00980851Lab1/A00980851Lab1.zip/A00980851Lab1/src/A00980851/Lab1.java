package A00980851;

import A00980851.data.music.AudioFile;
import A00980851.data.music.CompactDisk;
import A00980851.data.music.VinylRecordAlbum;

/**
 * Name Japneet Johal A00 980 851 
 * Project Name lab1 
 * Class Name Lab1 
 * Date 2017-04-26
 */
public class Lab1 {

	public Lab1() {
	}

	public static void main(String[] args) {
		new Lab1().test();
	}

	public void test() {
		// was not sure if you wanted these test so i left them in and commented them out
		
		
//		VinylRecordAlbum vinylRecordAlbum = new VinylRecordAlbum("Spin me", "The Spinners", 12);
//		System.out.println(vinylRecordAlbum.toString());
//		vinylRecordAlbum.setWeight(110);
//		System.out.println(vinylRecordAlbum.toString());
//		vinylRecordAlbum.setWeight(180);
//		System.out.println(vinylRecordAlbum.toString());
//		vinylRecordAlbum.play();
//
//		CompactDisk compactDisk = new CompactDisk("Turnabout intruder", "Jim Kirk", 9);
//		compactDisk.play();
//		System.out.println(compactDisk.toString());
//
//		AudioFile audioFile = new AudioFile("Buzz  click", "Cyber Punks", "FileNAme", 3.4);
//		audioFile.play();
//		audioFile.save("C://itunes/filder", "boughtVinal.mp4");
//		audioFile.delete("C://itunes/filder", "boughtVinal.mp4");
	}
}
