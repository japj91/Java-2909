package A00980851.io;

/**
 * Name Japneet Johal A00 980 851 Project Name lab1 Class Name FileManager Date
 * 2017-04-26
 */
public interface FileManager {

	public void delete(String path, String fileSize);

	public void save(String path, String fileSize);
}
